export default function ReportEmergency(){return <div>Report Emergency</div>}
