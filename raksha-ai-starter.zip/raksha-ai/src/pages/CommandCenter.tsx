export default function CommandCenter(){return <div>Command Center</div>}
