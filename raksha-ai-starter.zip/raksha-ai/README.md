# RAKSHA AI

AI-powered disaster response & coordination platform for Smart India Hackathon 2026.

Flow: Citizen report → AI triage → priority queue → command center → resource recommendation → dispatch → responder update → resolution.

## Stack
React + TypeScript + Vite • Supabase • Leaflet/React Leaflet • Supabase Edge Functions

## Run
npm install
cp .env.example .env.local
npm run dev

Never commit `.env.local` or private API keys.
