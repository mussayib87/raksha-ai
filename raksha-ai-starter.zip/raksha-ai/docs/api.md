# API Plan

Client services: incidents, resources, dispatch, ai. AI belongs in the Edge Function.
