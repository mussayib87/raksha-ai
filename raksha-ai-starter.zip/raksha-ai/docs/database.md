# Database

Tables: profiles, incidents, resources, dispatches, incident_updates.
Schema: `supabase/migrations/001_initial_schema.sql`.
