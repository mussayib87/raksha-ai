# SIH 2026 Requirements

Add the official AITM problem statement, PPT template, evaluation criteria, deadlines, team rules and submission requirements here.
