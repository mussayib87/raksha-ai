# Demo Script

1. Open Command Center. 2. Simulate flood. 3. Show AI priority queue and map. 4. Dispatch resource. 5. Show responder update. 6. Show analytics.
