# RAKSHA AI Architecture

Citizen → Supabase → AI triage → priority queue → command center → resource matching → dispatch → responder → resolution.
